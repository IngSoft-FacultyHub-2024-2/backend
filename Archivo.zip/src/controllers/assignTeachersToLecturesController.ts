import {
  assignTeachersToSemesterLectures,
  getAssignationsConflicts,
} from '../modules/assignTeachersToLectures';
import { Response, Request } from 'express';
import { returnError } from '../shared/utils/exceptions/handleExceptions';

class AssignTeachersToLecturesController {
  async assignTeachersToSemesterLectures(req: Request, res: Response) {
    try {
      const { semesterId } = req.body;
      if (!semesterId || isNaN(Number(semesterId))) {
        throw new Error('El semetreId es invalido');
      }
      const result = await assignTeachersToSemesterLectures(
        semesterId
      );
      res.status(200).json(result);
    } catch (error) {
      if (error instanceof Error) {
        returnError(res, error);
      }
    }
  }

  async getAssignationsConflicts(req: Request, res: Response) {
    try {
      const { semesterId } = req.params;
      const semesterIdNumber = parseInt(semesterId, 10);
      if (isNaN(semesterIdNumber)) {
        return res.status(400).json({ message: 'Invalid semesterId' });
      }
      const result = await getAssignationsConflicts(semesterIdNumber);
      res.status(200).json(result);
    } catch (error) {
      if (error instanceof Error) {
        console.log(error);
        returnError(res, error);
      }
    }
  }
}

export default new AssignTeachersToLecturesController();
