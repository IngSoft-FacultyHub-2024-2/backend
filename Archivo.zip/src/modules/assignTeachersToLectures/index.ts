import {
  assignTeachersToSemesterLectures,
  getAssignationsConflicts,
} from './services/teacherToAssignation';

export { assignTeachersToSemesterLectures, getAssignationsConflicts };
