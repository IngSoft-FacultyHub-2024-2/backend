import { login } from './services/authService';

export { login };
