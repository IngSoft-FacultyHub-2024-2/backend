export interface FileDataDto {
  fileType: string;
  semesterId?: number;
}
