
export const fileTypes = {
    COURSES : 'COURSES',
    TEACHERS : 'TEACHERS',
}