export interface ModuleResponseDto {
  id: number;
  time: string;
  turn: string;
}
