import {
  assignTeachersToSemesterLectures,
  getAssignationsConflicts,
} from './services/teacherAssignationsService';

export { assignTeachersToSemesterLectures, getAssignationsConflicts };
